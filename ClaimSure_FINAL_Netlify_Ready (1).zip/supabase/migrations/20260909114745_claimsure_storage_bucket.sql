/*
# Create private storage bucket for user documents

1. Storage
- Create a private bucket named 'user_documents' for storing bills, invoices, warranties, policies, etc.
- Storage buckets are private by default; RLS policies on storage.objects will control access.

2. Storage RLS Policies
- Users can CRUD only their own files in the 'user_documents' bucket.
- Files are organized by user_id folder structure: user_documents/{user_id}/{filename}
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('user_documents', 'user_documents', false)
ON CONFLICT (id) DO NOTHING;

-- Allow users to read their own files
DROP POLICY IF EXISTS "Users can read own documents" ON storage.objects;
CREATE POLICY "Users can read own documents"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'user_documents' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Allow users to upload to their own folder
DROP POLICY IF EXISTS "Users can upload own documents" ON storage.objects;
CREATE POLICY "Users can upload own documents"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'user_documents' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Allow users to update their own files
DROP POLICY IF EXISTS "Users can update own documents" ON storage.objects;
CREATE POLICY "Users can update own documents"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'user_documents' AND (storage.foldername(name))[1] = auth.uid()::text)
WITH CHECK (bucket_id = 'user_documents' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Allow users to delete their own files
DROP POLICY IF EXISTS "Users can delete own documents" ON storage.objects;
CREATE POLICY "Users can delete own documents"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'user_documents' AND (storage.foldername(name))[1] = auth.uid()::text);
