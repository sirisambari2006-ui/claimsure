/*
# ClaimSure Schema Part 2 — Policies, Claims, Notifications

## Overview
Creates insurance policies, claims, claim documents, claim evidence, claim events,
and notifications tables. All owner-scoped with RLS.

## New Tables

### insurance_policies
- `id`, `user_id` (owner), `product_id` (nullable FK)
- `provider`, `policy_name`, `policy_type` (warranty/protection/vehicle/health/other)
- `policy_number`, `coverage` (jsonb array), `conditions` (text), `exclusions` (jsonb array)
- `required_documents` (jsonb array), `claim_channel`, `claim_deadline_days`
- `effective_date`, `expiry_date`, `source_document_id` (FK product_documents)
- `policy_status` (active/expired/cancelled)
- `ai_explanation` (text — clearly labeled AI-generated, separate from official wording)
- `is_demo`
- timestamps

### claims
- `id`, `user_id` (owner), `product_id` (FK), `policy_id` (nullable FK)
- `issue` (text), `claim_type` (warranty/insurance/protection/other)
- `status` (issue_reported/eligibility_check/documents_prepared/claim_submitted/verification/decision/resolved)
- `eligibility_result` (text: likely_eligible/needs_verification/likely_not_eligible)
- `eligibility_reasoning` (jsonb — structured explainable reasoning)
- `claim_readiness_score` (int 0-100, deterministically calculated)
- `readiness_breakdown` (jsonb — component scores)
- `reference_number` (text, user-provided)
- `deadline` (date)
- `notes` (text)
- `is_demo`
- timestamps

### claim_documents
- `id`, `user_id` (owner), `claim_id` (FK CASCADE)
- `name`, `storage_path`, `mime_type`, `file_size`
- `category` (evidence/support/other)
- timestamps

### claim_evidence
- `id`, `claim_id` (FK CASCADE), `user_id` (owner)
- `item` (text), `status` (available/missing/needs_verification)
- `document_id` (nullable FK product_documents)
- `is_required` (boolean)
- `created_at`

### claim_events
- `id`, `claim_id` (FK CASCADE), `user_id` (owner)
- `stage` (text), `description` (text), `event_date` (timestamptz)
- `created_at`

### notifications
- `id`, `user_id` (owner)
- `title`, `description`, `priority` (urgent/upcoming/informational/completed)
- `category` (emi/warranty/insurance/claim/document/other)
- `related_id` (uuid, nullable), `related_type` (text, nullable)
- `is_read` (boolean, default false), `due_date` (date, nullable)
- `created_at`

## Security
- RLS enabled on all tables.
- Owner-scoped CRUD (4 policies per table).
- Foreign keys with ON DELETE CASCADE for child tables.
*/

-- ============ insurance_policies ============
CREATE TABLE IF NOT EXISTS insurance_policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  provider text NOT NULL,
  policy_name text,
  policy_type text NOT NULL DEFAULT 'other',
  policy_number text,
  coverage jsonb DEFAULT '[]'::jsonb,
  conditions text,
  exclusions jsonb DEFAULT '[]'::jsonb,
  required_documents jsonb DEFAULT '[]'::jsonb,
  claim_channel text,
  claim_deadline_days int,
  effective_date date,
  expiry_date date,
  source_document_id uuid REFERENCES product_documents(id) ON DELETE SET NULL,
  policy_status text DEFAULT 'active',
  ai_explanation text,
  is_demo boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE insurance_policies ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_policies" ON insurance_policies;
CREATE POLICY "select_own_policies" ON insurance_policies FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_policies" ON insurance_policies;
CREATE POLICY "insert_own_policies" ON insurance_policies FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_policies" ON insurance_policies;
CREATE POLICY "update_own_policies" ON insurance_policies FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_policies" ON insurance_policies;
CREATE POLICY "delete_own_policies" ON insurance_policies FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_policies_user_id ON insurance_policies(user_id);
CREATE INDEX IF NOT EXISTS idx_policies_expiry ON insurance_policies(expiry_date);

-- ============ claims ============
CREATE TABLE IF NOT EXISTS claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  policy_id uuid REFERENCES insurance_policies(id) ON DELETE SET NULL,
  issue text NOT NULL,
  claim_type text DEFAULT 'warranty',
  status text DEFAULT 'issue_reported',
  eligibility_result text,
  eligibility_reasoning jsonb DEFAULT '{}'::jsonb,
  claim_readiness_score int DEFAULT 0,
  readiness_breakdown jsonb DEFAULT '{}'::jsonb,
  reference_number text,
  deadline date,
  notes text,
  is_demo boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE claims ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_claims" ON claims;
CREATE POLICY "select_own_claims" ON claims FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_claims" ON claims;
CREATE POLICY "insert_own_claims" ON claims FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_claims" ON claims;
CREATE POLICY "update_own_claims" ON claims FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_claims" ON claims;
CREATE POLICY "delete_own_claims" ON claims FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_claims_user_id ON claims(user_id);
CREATE INDEX IF NOT EXISTS idx_claims_status ON claims(status);

-- ============ claim_documents ============
CREATE TABLE IF NOT EXISTS claim_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  claim_id uuid NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  name text NOT NULL,
  storage_path text,
  mime_type text,
  file_size bigint,
  category text DEFAULT 'evidence',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE claim_documents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_claim_documents" ON claim_documents;
CREATE POLICY "select_own_claim_documents" ON claim_documents FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_claim_documents" ON claim_documents;
CREATE POLICY "insert_own_claim_documents" ON claim_documents FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_claim_documents" ON claim_documents;
CREATE POLICY "update_own_claim_documents" ON claim_documents FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_claim_documents" ON claim_documents;
CREATE POLICY "delete_own_claim_documents" ON claim_documents FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_claim_documents_claim_id ON claim_documents(claim_id);

-- ============ claim_evidence ============
CREATE TABLE IF NOT EXISTS claim_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id uuid NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  item text NOT NULL,
  status text DEFAULT 'missing',
  document_id uuid REFERENCES product_documents(id) ON DELETE SET NULL,
  is_required boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE claim_evidence ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_claim_evidence" ON claim_evidence;
CREATE POLICY "select_own_claim_evidence" ON claim_evidence FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_claim_evidence" ON claim_evidence;
CREATE POLICY "insert_own_claim_evidence" ON claim_evidence FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_claim_evidence" ON claim_evidence;
CREATE POLICY "update_own_claim_evidence" ON claim_evidence FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_claim_evidence" ON claim_evidence;
CREATE POLICY "delete_own_claim_evidence" ON claim_evidence FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_claim_evidence_claim_id ON claim_evidence(claim_id);

-- ============ claim_events ============
CREATE TABLE IF NOT EXISTS claim_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id uuid NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  stage text NOT NULL,
  description text,
  event_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE claim_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_claim_events" ON claim_events;
CREATE POLICY "select_own_claim_events" ON claim_events FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_claim_events" ON claim_events;
CREATE POLICY "insert_own_claim_events" ON claim_events FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_claim_events" ON claim_events;
CREATE POLICY "delete_own_claim_events" ON claim_events FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_claim_events_claim_id ON claim_events(claim_id);

-- ============ notifications ============
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  priority text DEFAULT 'informational',
  category text DEFAULT 'other',
  related_id uuid,
  related_type text,
  is_read boolean DEFAULT false,
  due_date date,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_notifications" ON notifications;
CREATE POLICY "select_own_notifications" ON notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_notifications" ON notifications;
CREATE POLICY "insert_own_notifications" ON notifications FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notifications" ON notifications;
CREATE POLICY "update_own_notifications" ON notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_notifications" ON notifications;
CREATE POLICY "delete_own_notifications" ON notifications FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);

-- ============ updated_at triggers for new tables ============
DROP TRIGGER IF EXISTS set_updated_at_policies ON insurance_policies;
CREATE TRIGGER set_updated_at_policies BEFORE UPDATE ON insurance_policies
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_claims ON claims;
CREATE TRIGGER set_updated_at_claims BEFORE UPDATE ON claims
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============ Add FK from product_documents to insurance_policies and claims ============
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'product_documents_policy_id_fkey'
  ) THEN
    ALTER TABLE product_documents
    ADD CONSTRAINT product_documents_policy_id_fkey
    FOREIGN KEY (policy_id) REFERENCES insurance_policies(id) ON DELETE SET NULL;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'product_documents_claim_id_fkey'
  ) THEN
    ALTER TABLE product_documents
    ADD CONSTRAINT product_documents_claim_id_fkey
    FOREIGN KEY (claim_id) REFERENCES claims(id) ON DELETE SET NULL;
  END IF;
END $$;
