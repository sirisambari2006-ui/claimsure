/*
# ClaimSure Core Schema — Profiles, Products, Documents

## Overview
Creates the foundational tables for ClaimSure: user profiles, products, product documents,
EMI accounts, EMI payments, and audit logs. All tables are owner-scoped with RLS.

## New Tables

### profiles
- `id` (uuid, PK, references auth.users)
- `full_name` (text)
- `phone` (text)
- `preferred_language` (text, default 'en')
- `notification_prefs` (jsonb, default empty object)
- `created_at`, `updated_at` (timestamps)

### products
- `id` (uuid PK)
- `user_id` (uuid, owner, DEFAULT auth.uid())
- `name`, `category`, `brand`, `model`, `serial_number`
- `purchase_date`, `purchase_price`, `seller`, `payment_method`
- `warranty_period`, `warranty_expiry`
- `notes`
- `is_demo` (boolean, default false — flags clearly-labeled demo data)
- `created_at`, `updated_at`

### product_documents
- `id` (uuid PK)
- `user_id` (uuid, owner, DEFAULT auth.uid())
- `product_id` (uuid, FK → products, ON DELETE CASCADE)
- `policy_id` (uuid, nullable, FK → insurance_policies)
- `claim_id` (uuid, nullable, FK → claims)
- `name`, `category` (bill/invoice/warranty/insurance/service/claim_doc/evidence/other)
- `storage_path`, `mime_type`, `file_size`
- `extracted_data` (jsonb — AI/OCR extracted info, user-verified)
- `is_verified` (boolean — user confirmed the extracted data)
- `is_demo` (boolean)
- `created_at`, `updated_at`

### emi_accounts
- `id` (uuid PK)
- `user_id` (uuid, owner, DEFAULT auth.uid())
- `product_id` (uuid, FK → products, ON DELETE CASCADE)
- `total_amount`, `down_payment`, `emi_amount`
- `total_installments`, `paid_installments`
- `start_date`, `next_due_date`, `completion_date`
- `status` (text: active/completed/overdue)
- `is_demo` (boolean)
- `created_at`, `updated_at`

### emi_payments
- `id` (uuid PK)
- `emi_account_id` (uuid, FK → emi_accounts, ON DELETE CASCADE)
- `user_id` (uuid, owner, DEFAULT auth.uid())
- `amount`, `installment_number`, `payment_date`
- `status` (text: paid/pending/failed)
- `created_at`

### audit_logs
- `id` (uuid PK)
- `user_id` (uuid, owner, DEFAULT auth.uid())
- `action` (text)
- `entity_type` (text)
- `entity_id` (uuid, nullable)
- `details` (jsonb)
- `created_at`

## Security
- RLS enabled on all tables.
- Owner-scoped CRUD policies (4 per table) using auth.uid() = user_id.
- Child tables (product_documents, emi_payments) also carry user_id for direct ownership checks.
*/

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============ profiles ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  phone text,
  preferred_language text DEFAULT 'en',
  notification_prefs jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

-- ============ products ============
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  category text NOT NULL,
  brand text,
  model text,
  serial_number text,
  purchase_date date,
  purchase_price numeric(12,2),
  seller text,
  payment_method text,
  warranty_period text,
  warranty_expiry date,
  notes text,
  is_demo boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_products" ON products;
CREATE POLICY "select_own_products" ON products FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_products" ON products;
CREATE POLICY "insert_own_products" ON products FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_products" ON products;
CREATE POLICY "update_own_products" ON products FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_products" ON products;
CREATE POLICY "delete_own_products" ON products FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_products_user_id ON products(user_id);
CREATE INDEX IF NOT EXISTS idx_products_warranty_expiry ON products(warranty_expiry);

-- ============ product_documents ============
CREATE TABLE IF NOT EXISTS product_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  policy_id uuid,
  claim_id uuid,
  name text NOT NULL,
  category text NOT NULL DEFAULT 'other',
  storage_path text,
  mime_type text,
  file_size bigint,
  extracted_data jsonb DEFAULT '{}'::jsonb,
  is_verified boolean DEFAULT false,
  is_demo boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE product_documents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_product_documents" ON product_documents;
CREATE POLICY "select_own_product_documents" ON product_documents FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_product_documents" ON product_documents;
CREATE POLICY "insert_own_product_documents" ON product_documents FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_product_documents" ON product_documents;
CREATE POLICY "update_own_product_documents" ON product_documents FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_product_documents" ON product_documents;
CREATE POLICY "delete_own_product_documents" ON product_documents FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_product_documents_user_id ON product_documents(user_id);
CREATE INDEX IF NOT EXISTS idx_product_documents_product_id ON product_documents(product_id);

-- ============ emi_accounts ============
CREATE TABLE IF NOT EXISTS emi_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  total_amount numeric(12,2) NOT NULL DEFAULT 0,
  down_payment numeric(12,2) DEFAULT 0,
  emi_amount numeric(12,2) DEFAULT 0,
  total_installments int DEFAULT 0,
  paid_installments int DEFAULT 0,
  start_date date,
  next_due_date date,
  completion_date date,
  status text DEFAULT 'active',
  is_demo boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE emi_accounts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_emi_accounts" ON emi_accounts;
CREATE POLICY "select_own_emi_accounts" ON emi_accounts FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_emi_accounts" ON emi_accounts;
CREATE POLICY "insert_own_emi_accounts" ON emi_accounts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_emi_accounts" ON emi_accounts;
CREATE POLICY "update_own_emi_accounts" ON emi_accounts FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_emi_accounts" ON emi_accounts;
CREATE POLICY "delete_own_emi_accounts" ON emi_accounts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_emi_accounts_user_id ON emi_accounts(user_id);

-- ============ emi_payments ============
CREATE TABLE IF NOT EXISTS emi_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  emi_account_id uuid NOT NULL REFERENCES emi_accounts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  amount numeric(12,2) NOT NULL,
  installment_number int NOT NULL,
  payment_date date NOT NULL,
  status text DEFAULT 'paid',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE emi_payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_emi_payments" ON emi_payments;
CREATE POLICY "select_own_emi_payments" ON emi_payments FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_emi_payments" ON emi_payments;
CREATE POLICY "insert_own_emi_payments" ON emi_payments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_emi_payments" ON emi_payments;
CREATE POLICY "update_own_emi_payments" ON emi_payments FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_emi_payments" ON emi_payments;
CREATE POLICY "delete_own_emi_payments" ON emi_payments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_emi_payments_account_id ON emi_payments(emi_account_id);

-- ============ audit_logs ============
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  action text NOT NULL,
  entity_type text,
  entity_id uuid,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_audit_logs" ON audit_logs;
CREATE POLICY "select_own_audit_logs" ON audit_logs FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_audit_logs" ON audit_logs;
CREATE POLICY "insert_own_audit_logs" ON audit_logs FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_audit_logs" ON audit_logs;
CREATE POLICY "delete_own_audit_logs" ON audit_logs FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);

-- ============ updated_at trigger ============
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS set_updated_at_profiles ON profiles;
CREATE TRIGGER set_updated_at_profiles BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_products ON products;
CREATE TRIGGER set_updated_at_products BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_product_documents ON product_documents;
CREATE TRIGGER set_updated_at_product_documents BEFORE UPDATE ON product_documents
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_emi_accounts ON emi_accounts;
CREATE TRIGGER set_updated_at_emi_accounts BEFORE UPDATE ON emi_accounts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
