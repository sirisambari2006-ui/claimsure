import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' };
serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const { fileName, mimeType, base64 } = await req.json();
    const key = Deno.env.get('OPENAI_API_KEY');
    if (!key) return new Response(JSON.stringify({ error: 'OPENAI_API_KEY is not configured.' }), { status: 503, headers: { ...cors, 'Content-Type': 'application/json' } });
    const prompt = `Extract structured fields from this purchase/warranty/insurance document. Return ONLY valid JSON with keys: product, brand, model, purchase_date, amount, seller, warranty_period, warranty_expiry, policy_number, provider, policy_start, policy_expiry, coverage, exclusions, emi_amount, total_installments. Use null when unavailable. Do not invent values.`;
    const response = await fetch('https://api.openai.com/v1/responses', { method:'POST', headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'}, body:JSON.stringify({model:Deno.env.get('OPENAI_DOCUMENT_MODEL')||'gpt-4.1-mini',input:[{role:'user',content:[{type:'input_text',text:prompt},{type:'input_file',filename:fileName,file_data:`data:${mimeType};base64,${base64}`}]}],temperature:0}) });
    if (!response.ok) throw new Error(`Document AI request failed (${response.status}).`);
    const result = await response.json();
    const text = result.output?.flatMap((x:any)=>x.content||[]).find((x:any)=>x.type==='output_text')?.text || '{}';
    let extracted: Record<string,unknown> = {};
    try { extracted = JSON.parse(text); } catch { extracted = { raw_text: text }; }
    return new Response(JSON.stringify({ extracted, confidence: 0.8 }), { headers:{...cors,'Content-Type':'application/json'} });
  } catch (e) { return new Response(JSON.stringify({ error: e instanceof Error ? e.message : 'Unknown error' }), { status:500, headers:{...cors,'Content-Type':'application/json'} }); }
});
