# ClaimSure

ClaimSure is an AI-assisted claim-intelligence and protection-management web app.

## Included in this build
- Supabase authentication and protected routes
- Products CRUD and warranty tracking
- EMI tracking
- Policy management
- Claim Intelligence eligibility assessment
- Deterministic Claim Readiness Score
- Evidence checklist and claim journey
- Private Digital Locker using Supabase Storage
- AI document-extraction integration through a Supabase Edge Function
- AI Claim Assistant integration through a Supabase Edge Function
- Multilingual UI foundation
- Profile, security, notifications and settings pages
- Responsive professional dashboard

## Run locally
1. `npm install`
2. Copy `.env.example` to `.env`
3. Add your Supabase URL and anon key.
4. Apply the SQL migrations in `supabase/migrations/` to your Supabase project.
5. `npm run dev`

## Optional AI setup
The AI features are intentionally fail-safe. To enable them, deploy the Edge Functions under `supabase/functions/` and configure `OPENAI_API_KEY` as a Supabase secret. The functions never expose the API key to the browser.

## Important
The claim engine is an AI-assisted/deterministic assessment tool, not a guarantee of claim approval. Official policy wording must remain the source of truth.

Never commit `.env` or any secret key to GitHub.
