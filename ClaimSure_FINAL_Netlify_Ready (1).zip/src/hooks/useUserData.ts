import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type {
  Product,
  ProductDocument,
  InsurancePolicy,
  Claim,
  EMIAccount,
  Notification,
  AuditLog,
} from '@/types';

export function useUserData() {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [documents, setDocuments] = useState<ProductDocument[]>([]);
  const [policies, setPolicies] = useState<InsurancePolicy[]>([]);
  const [claims, setClaims] = useState<Claim[]>([]);
  const [emis, setEmis] = useState<EMIAccount[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAll = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(null);

    try {
      const [productsRes, docsRes, policiesRes, claimsRes, emisRes, notifsRes, logsRes] =
        await Promise.all([
          supabase.from('products').select('*').order('created_at', { ascending: false }),
          supabase.from('product_documents').select('*').order('created_at', { ascending: false }),
          supabase.from('insurance_policies').select('*').order('created_at', { ascending: false }),
          supabase.from('claims').select('*').order('created_at', { ascending: false }),
          supabase.from('emi_accounts').select('*').order('created_at', { ascending: false }),
          supabase.from('notifications').select('*').order('created_at', { ascending: false }),
          supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(20),
        ]);

      setProducts((productsRes.data as Product[]) || []);
      setDocuments((docsRes.data as ProductDocument[]) || []);
      setPolicies((policiesRes.data as InsurancePolicy[]) || []);
      setClaims((claimsRes.data as Claim[]) || []);
      setEmis((emisRes.data as EMIAccount[]) || []);
      setNotifications((notifsRes.data as Notification[]) || []);
      setAuditLogs((logsRes.data as AuditLog[]) || []);
    } catch {
      setError('Failed to load data. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  return {
    products,
    documents,
    policies,
    claims,
    emis,
    notifications,
    auditLogs,
    loading,
    error,
    refresh: fetchAll,
  };
}
