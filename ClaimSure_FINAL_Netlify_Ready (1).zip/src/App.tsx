import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/context/AuthContext';
import { I18nProvider } from '@/context/I18nContext';
import { ToastProvider } from '@/context/ToastContext';
import { ProtectedRoute, PublicOnlyRoute } from '@/components/ProtectedRoute';
import { AppLayout } from '@/components/AppLayout';

import LandingPage from '@/pages/LandingPage';
import LoginPage from '@/pages/auth/LoginPage';
import SignupPage from '@/pages/auth/SignupPage';
import ForgotPasswordPage from '@/pages/auth/ForgotPasswordPage';
import VerifyEmailPage from '@/pages/auth/VerifyEmailPage';
import DashboardPage from '@/pages/DashboardPage';
import ProductsPage from '@/pages/ProductsPage';
import ProductDetailPage from '@/pages/ProductDetailPage';
import EmisPage from '@/pages/EmisPage';
import PoliciesPage from '@/pages/PoliciesPage';
import ClaimsPage from '@/pages/ClaimsPage';
import ClaimDetailPage from '@/pages/ClaimDetailPage';
import LockerPage from '@/pages/LockerPage';
import AssistantPage from '@/pages/AssistantPage';
import NotificationsPage from '@/pages/NotificationsPage';
import ProfilePage from '@/pages/ProfilePage';
import SecurityPage from '@/pages/SecurityPage';
import SettingsPage from '@/pages/SettingsPage';

export default function App() {
  return (
    <AuthProvider>
      <I18nProvider>
        <ToastProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/login" element={<PublicOnlyRoute><LoginPage /></PublicOnlyRoute>} />
              <Route path="/signup" element={<PublicOnlyRoute><SignupPage /></PublicOnlyRoute>} />
              <Route path="/forgot-password" element={<PublicOnlyRoute><ForgotPasswordPage /></PublicOnlyRoute>} />
              <Route path="/verify-email" element={<PublicOnlyRoute><VerifyEmailPage /></PublicOnlyRoute>} />

              <Route path="/dashboard" element={<ProtectedRoute><AppLayout><DashboardPage /></AppLayout></ProtectedRoute>} />
              <Route path="/products" element={<ProtectedRoute><AppLayout><ProductsPage /></AppLayout></ProtectedRoute>} />
              <Route path="/products/:id" element={<ProtectedRoute><AppLayout><ProductDetailPage /></AppLayout></ProtectedRoute>} />
              <Route path="/emis" element={<ProtectedRoute><AppLayout><EmisPage /></AppLayout></ProtectedRoute>} />
              <Route path="/policies" element={<ProtectedRoute><AppLayout><PoliciesPage /></AppLayout></ProtectedRoute>} />
              <Route path="/claims" element={<ProtectedRoute><AppLayout><ClaimsPage /></AppLayout></ProtectedRoute>} />
              <Route path="/claims/:id" element={<ProtectedRoute><AppLayout><ClaimDetailPage /></AppLayout></ProtectedRoute>} />
              <Route path="/locker" element={<ProtectedRoute><AppLayout><LockerPage /></AppLayout></ProtectedRoute>} />
              <Route path="/assistant" element={<ProtectedRoute><AppLayout><AssistantPage /></AppLayout></ProtectedRoute>} />
              <Route path="/notifications" element={<ProtectedRoute><AppLayout><NotificationsPage /></AppLayout></ProtectedRoute>} />
              <Route path="/profile" element={<ProtectedRoute><AppLayout><ProfilePage /></AppLayout></ProtectedRoute>} />
              <Route path="/security" element={<ProtectedRoute><AppLayout><SecurityPage /></AppLayout></ProtectedRoute>} />
              <Route path="/settings" element={<ProtectedRoute><AppLayout><SettingsPage /></AppLayout></ProtectedRoute>} />

              <Route path="*" element={<ProtectedRoute><AppLayout><DashboardPage /></AppLayout></ProtectedRoute>} />
            </Routes>
          </BrowserRouter>
        </ToastProvider>
      </I18nProvider>
    </AuthProvider>
  );
}
