import { type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Package,
  CreditCard,
  ShieldCheck,
  FileText,
  Lock,
  Bot,
  Bell,
  User,
  Settings,
  LogOut,
  Menu,
  X,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useI18n } from '@/context/I18nContext';
import { useState } from 'react';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';

interface NavItem {
  to: string;
  icon: typeof LayoutDashboard;
  labelKey: string;
}

const navItems: NavItem[] = [
  { to: '/dashboard', icon: LayoutDashboard, labelKey: 'nav.dashboard' },
  { to: '/products', icon: Package, labelKey: 'nav.products' },
  { to: '/emis', icon: CreditCard, labelKey: 'nav.emis' },
  { to: '/policies', icon: ShieldCheck, labelKey: 'nav.policies' },
  { to: '/claims', icon: FileText, labelKey: 'nav.claims' },
  { to: '/locker', icon: Lock, labelKey: 'nav.locker' },
  { to: '/assistant', icon: Bot, labelKey: 'nav.assistant' },
  { to: '/notifications', icon: Bell, labelKey: 'nav.notifications' },
];

const bottomNavItems: NavItem[] = [
  { to: '/profile', icon: User, labelKey: 'nav.profile' },
  { to: '/security', icon: ShieldCheck, labelKey: 'nav.security' },
  { to: '/settings', icon: Settings, labelKey: 'nav.settings' },
];

export function AppLayout({ children }: { children: ReactNode }) {
  const { user, profile, signOut } = useAuth();
  const { t } = useI18n();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const fullName = profile?.full_name || user?.email?.split('@')[0] || 'User';
  const initials = fullName
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-navy-950/40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-40 h-screen w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center justify-between px-5 py-5 border-b border-slate-200">
          <Link to="/dashboard" className="flex items-center gap-2.5" onClick={() => setSidebarOpen(false)}>
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary-600 to-navy-700 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-lg text-navy-900">ClaimSure</span>
          </Link>
          <button
            className="lg:hidden text-slate-400 hover:text-slate-600"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 px-3 py-4 overflow-y-auto scrollbar-thin">
          <ul className="space-y-1">
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink to={item.to} icon={item.icon} label={t(item.labelKey)} onClick={() => setSidebarOpen(false)} />
              </li>
            ))}
          </ul>

          <div className="my-4 border-t border-slate-100" />

          <ul className="space-y-1">
            {bottomNavItems.map((item) => (
              <li key={item.to}>
                <NavLink to={item.to} icon={item.icon} label={t(item.labelKey)} onClick={() => setSidebarOpen(false)} />
              </li>
            ))}
          </ul>
        </nav>

        <div className="px-3 py-4 border-t border-slate-200">
          <div className="flex items-center gap-3 px-2 py-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary-100 to-navy-100 flex items-center justify-center text-sm font-semibold text-primary-700">
              {initials}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-navy-800 truncate">{fullName}</p>
              <p className="text-xs text-slate-400 truncate">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={() => signOut()}
            className="mt-2 w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-slate-500 hover:bg-slate-50 hover:text-error-600 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            {t('nav.logout')}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Mobile header */}
        <header className="lg:hidden sticky top-0 z-20 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
          <button onClick={() => setSidebarOpen(true)} className="text-slate-500 hover:text-navy-900">
            <Menu className="w-6 h-6" />
          </button>
          <Link to="/dashboard" className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary-600 to-navy-700 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold text-navy-900">ClaimSure</span>
          </Link>
          <div className="w-6"><LanguageSwitcher compact /></div>
        </header>

        {/* Desktop top bar */}
        <header className="hidden lg:flex sticky top-0 z-20 bg-white/80 backdrop-blur-sm border-b border-slate-200 px-6 py-3 items-center justify-between">
          <div />
          <div className="flex items-center gap-3">
            <LanguageSwitcher />
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6 xl:p-8">{children}</main>
      </div>
    </div>
  );
}

function NavLink({
  to,
  icon: Icon,
  label,
  onClick,
}: {
  to: string;
  icon: typeof LayoutDashboard;
  label: string;
  onClick?: () => void;
}) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-navy-900 transition-colors"
    >
      <Icon className="w-5 h-5 shrink-0" />
      {label}
    </Link>
  );
}
