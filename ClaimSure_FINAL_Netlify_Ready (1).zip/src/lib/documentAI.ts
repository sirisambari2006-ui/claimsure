import { supabase } from '@/lib/supabase';

export async function extractDocument(file: File) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  const base64 = btoa(binary);
  const { data, error } = await supabase.functions.invoke('document-extract', {
    body: { fileName: file.name, mimeType: file.type || 'application/octet-stream', base64 },
  });
  if (error) throw new Error(error.message || 'Document AI is not configured.');
  return data as { extracted: Record<string, unknown>; confidence?: number };
}
