import type { Product, InsurancePolicy, ProductDocument, ClaimEvidence } from '@/types';

interface ReadinessComponent {
  label: string;
  score: number;
  max: number;
  description: string;
}

export interface ClaimReadinessResult {
  total: number;
  components: ReadinessComponent[];
  missingItems: string[];
}

export function calculateClaimReadiness(
  product: Product | null,
  documents: ProductDocument[],
  policies: InsurancePolicy[],
  issueDescription: string,
  evidence: ClaimEvidence[] = []
): ClaimReadinessResult {
  const components: ReadinessComponent[] = [];
  const missingItems: string[] = [];

  // 1. Purchase proof (20 pts)
  const hasPurchaseDoc = documents.some(
    (d) => d.category === 'bill' || d.category === 'invoice'
  );
  components.push({
    label: 'Purchase Proof',
    score: hasPurchaseDoc ? 20 : 0,
    max: 20,
    description: hasPurchaseDoc
      ? 'Purchase invoice or bill is available.'
      : 'Purchase invoice or bill is missing.',
  });
  if (!hasPurchaseDoc) missingItems.push('Purchase invoice or bill');

  // 2. Product identification (20 pts)
  const hasProductInfo = product?.serial_number && product?.brand && product?.model;
  const productScore = product
    ? (product.serial_number ? 7 : 0) + (product.brand ? 7 : 0) + (product.model ? 6 : 0)
    : 0;
  components.push({
    label: 'Product Identification',
    score: productScore,
    max: 20,
    description:
      productScore === 20
        ? 'Product serial number, brand, and model are all recorded.'
        : 'Some product identification details are missing.',
  });
  if (productScore < 20) {
    if (!product?.serial_number) missingItems.push('Product serial number');
    if (!product?.brand) missingItems.push('Product brand');
    if (!product?.model) missingItems.push('Product model');
  }

  // 3. Warranty/policy document (20 pts)
  const hasWarrantyDoc = documents.some((d) => d.category === 'warranty');
  const hasPolicy = policies.length > 0;
  const warrantyScore = (hasWarrantyDoc ? 10 : 0) + (hasPolicy ? 10 : 0);
  components.push({
    label: 'Warranty/Policy Evidence',
    score: warrantyScore,
    max: 20,
    description:
      warrantyScore === 20
        ? 'Warranty document and insurance policy are available.'
        : warrantyScore === 10
          ? hasWarrantyDoc
            ? 'Warranty document available, but no insurance policy on file.'
            : 'Insurance policy available, but no warranty document on file.'
          : 'Neither warranty document nor insurance policy is available.',
  });
  if (!hasWarrantyDoc) missingItems.push('Warranty document');
  if (!hasPolicy) missingItems.push('Insurance policy');

  // 4. Issue description (10 pts)
  const hasIssue = issueDescription && issueDescription.trim().length > 10;
  components.push({
    label: 'Issue Description',
    score: hasIssue ? 10 : 0,
    max: 10,
    description: hasIssue
      ? 'A detailed issue description has been provided.'
      : 'No issue description has been provided yet.',
  });
  if (!hasIssue) missingItems.push('Detailed issue description');

  // 5. Supporting evidence (30 pts)
  const availableEvidence = evidence.filter((e) => e.status === 'available').length;
  const totalEvidence = evidence.length > 0 ? evidence.length : 1;
  const evidenceScore = Math.round((availableEvidence / totalEvidence) * 30);
  components.push({
    label: 'Supporting Evidence',
    score: evidenceScore,
    max: 30,
    description:
      evidence.length === 0
        ? 'No evidence checklist has been generated yet.'
        : `${availableEvidence} of ${evidence.length} evidence items are available.`,
  });
  if (evidence.length > 0) {
    evidence
      .filter((e) => e.status === 'missing' && e.is_required)
      .forEach((e) => missingItems.push(e.item));
  }

  const total = components.reduce((sum, c) => sum + c.score, 0);

  return { total, components, missingItems };
}

export interface EligibilityAssessment {
  result: 'likely_eligible' | 'needs_verification' | 'likely_not_eligible';
  reasoning: {
    summary: string;
    factors: { factor: string; status: 'positive' | 'negative' | 'neutral'; detail: string }[];
    policyConsidered: string | null;
    coverageMatched: string[];
    evidenceMissing: string[];
    nextSteps: string[];
  };
}

export function assessEligibility(
  product: Product | null,
  policies: InsurancePolicy[],
  documents: ProductDocument[],
  issueDescription: string,
  issueType?: string
): EligibilityAssessment {
  const factors: EligibilityAssessment['reasoning']['factors'] = [];
  const coverageMatched: string[] = [];
  const evidenceMissing: string[] = [];
  const nextSteps: string[] = [];
  let positiveCount = 0;
  let negativeCount = 0;

  // Check warranty status
  const today = new Date();
  const warrantyExpiry = product?.warranty_expiry
    ? new Date(product.warranty_expiry)
    : null;
  const withinWarranty = warrantyExpiry ? warrantyExpiry > today : false;

  if (product) {
    if (withinWarranty) {
      factors.push({
        factor: 'Warranty Status',
        status: 'positive',
        detail: 'Product is within the recorded warranty period.',
      });
      positiveCount++;
      coverageMatched.push('Hardware malfunction (if applicable under warranty terms)');
    } else if (warrantyExpiry) {
      factors.push({
        factor: 'Warranty Status',
        status: 'negative',
        detail: 'Product warranty has expired.',
      });
      negativeCount++;
    } else {
      factors.push({
        factor: 'Warranty Status',
        status: 'neutral',
        detail: 'No warranty expiry date is recorded.',
      });
    }
  }

  // Check purchase document
  const hasPurchaseDoc = documents.some(
    (d) => d.category === 'bill' || d.category === 'invoice'
  );
  factors.push({
    factor: 'Purchase Proof',
    status: hasPurchaseDoc ? 'positive' : 'negative',
    detail: hasPurchaseDoc
      ? 'Purchase invoice is available.'
      : 'Purchase invoice is missing.',
  });
  hasPurchaseDoc ? positiveCount++ : negativeCount++;
  if (!hasPurchaseDoc) evidenceMissing.push('Purchase invoice');

  // Check warranty document
  const hasWarrantyDoc = documents.some((d) => d.category === 'warranty');
  factors.push({
    factor: 'Warranty Document',
    status: hasWarrantyDoc ? 'positive' : 'negative',
    detail: hasWarrantyDoc
      ? 'Warranty document is available.'
      : 'Warranty document is missing.',
  });
  hasWarrantyDoc ? positiveCount++ : negativeCount++;
  if (!hasWarrantyDoc) evidenceMissing.push('Warranty document');

  // Check insurance policy
  if (policies.length > 0) {
    const activePolicy = policies.find((p) => p.policy_status === 'active');
    if (activePolicy) {
      factors.push({
        factor: 'Insurance Policy',
        status: 'positive',
        detail: `Active policy found: ${activePolicy.provider} - ${activePolicy.policy_name || activePolicy.policy_type}.`,
      });
      positiveCount++;
      coverageMatched.push(...(activePolicy.coverage || []));
    } else {
      factors.push({
        factor: 'Insurance Policy',
        status: 'neutral',
        detail: 'Insurance policy exists but may not be active.',
      });
    }
  }

  // Check service report
  const hasServiceReport = documents.some((d) => d.category === 'service');
  if (!hasServiceReport) {
    factors.push({
      factor: 'Service Report',
      status: 'neutral',
      detail: 'Service report is not available. This may be needed for verification.',
    });
    evidenceMissing.push('Service report');
  }

  // Issue type analysis
  if (issueType) {
    factors.push({
      factor: 'Issue Type',
      status: 'neutral',
      detail: `Reported issue type: ${issueType}. This requires verification against policy terms.`,
    });
  }

  // Determine result
  let result: EligibilityAssessment['result'];
  if (positiveCount >= 3 && negativeCount <= 1) {
    result = 'likely_eligible';
    nextSteps.push('Gather all supporting evidence and submit your claim.');
    nextSteps.push('Contact the warranty provider or insurance company to initiate the claim.');
  } else if (negativeCount >= 2) {
    result = 'likely_not_eligible';
    nextSteps.push('Review whether an active insurance policy covers this type of issue.');
    nextSteps.push('Consider contacting the provider directly to confirm eligibility.');
  } else {
    result = 'needs_verification';
    nextSteps.push('Upload missing documents to improve claim readiness.');
    nextSteps.push('Contact the authorized service provider for a service report.');
    nextSteps.push('Verify coverage details against the original policy document.');
  }

  if (evidenceMissing.length > 0) {
    nextSteps.unshift(`Upload missing evidence: ${evidenceMissing.join(', ')}.`);
  }

  const policyConsidered = policies.length > 0
    ? policies[0].policy_name || policies[0].provider
    : product?.warranty_expiry
      ? withinWarranty
        ? 'Manufacturer Warranty'
        : null
      : null;

  return {
    result,
    reasoning: {
      summary: `Based on ${positiveCount} positive and ${negativeCount} negative factors from the available information, this claim is ${result === 'likely_eligible' ? 'likely eligible' : result === 'needs_verification' ? 'in need of verification' : 'likely not eligible'}.`,
      factors,
      policyConsidered,
      coverageMatched: [...new Set(coverageMatched)],
      evidenceMissing,
      nextSteps,
    },
  };
}

export function generateEvidenceChecklist(
  product: Product | null,
  policies: InsurancePolicy[],
  documents: ProductDocument[]
): { item: string; isRequired: boolean; status: 'available' | 'missing' | 'needs_verification' }[] {
  const checklist: { item: string; isRequired: boolean; status: 'available' | 'missing' | 'needs_verification' }[] = [];

  const hasDoc = (cat: string) => documents.some((d) => d.category === cat);

  checklist.push({
    item: 'Purchase invoice',
    isRequired: true,
    status: hasDoc('bill') || hasDoc('invoice') ? 'available' : 'missing',
  });
  checklist.push({
    item: 'Warranty document',
    isRequired: true,
    status: hasDoc('warranty') ? 'available' : 'missing',
  });
  checklist.push({
    item: 'Product serial number',
    isRequired: true,
    status: product?.serial_number ? 'available' : 'missing',
  });
  checklist.push({
    item: 'Product photographs',
    isRequired: false,
    status: 'needs_verification',
  });
  checklist.push({
    item: 'Issue description',
    isRequired: true,
    status: 'needs_verification',
  });
  checklist.push({
    item: 'Service report',
    isRequired: false,
    status: hasDoc('service') ? 'available' : 'missing',
  });

  if (policies.length > 0) {
    checklist.push({
      item: 'Insurance policy document',
      isRequired: true,
      status: hasDoc('insurance') ? 'available' : 'missing',
    });
  }

  checklist.push({
    item: 'Identity/ownership evidence',
    isRequired: false,
    status: 'needs_verification',
  });

  return checklist;
}
