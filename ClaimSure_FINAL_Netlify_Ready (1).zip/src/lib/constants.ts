export const CATEGORIES: { label: string; value: string }[] = [
  { label: 'Laptop', value: 'Laptop' },
  { label: 'Mobile', value: 'Mobile' },
  { label: 'Camera', value: 'Camera' },
  { label: 'Television', value: 'Television' },
  { label: 'Refrigerator', value: 'Refrigerator' },
  { label: 'Washing Machine', value: 'Washing Machine' },
  { label: 'Air Conditioner', value: 'Air Conditioner' },
  { label: 'Car', value: 'Car' },
  { label: 'Bike', value: 'Bike' },
  { label: 'Other', value: 'Other' },
];

export const BRANDS: Record<string, string[]> = {
  Laptop: ['Dell', 'HP', 'Lenovo', 'Apple', 'Asus', 'Acer', 'MSI'],
  Mobile: ['Samsung', 'Apple', 'OnePlus', 'Xiaomi', 'Realme', 'Vivo', 'Oppo'],
  Camera: ['Canon', 'Nikon', 'Sony', 'Fujifilm', 'Panasonic'],
  Television: ['Samsung', 'LG', 'Sony', 'Panasonic', 'TCL', 'Mi'],
  Refrigerator: ['Samsung', 'LG', 'Whirlpool', 'Godrej', 'Bosch'],
  'Washing Machine': ['Samsung', 'LG', 'Whirlpool', 'Bosch', 'IFB'],
  'Air Conditioner': ['Daikin', 'LG', 'Samsung', 'Voltas', 'Blue Star'],
  Car: ['Maruti Suzuki', 'Hyundai', 'Tata', 'Mahindra', 'Honda', 'Toyota', 'Kia'],
  Bike: ['Honda', 'Bajaj', 'Hero', 'TVS', 'Royal Enfield', 'Yamaha', 'KTM'],
  Other: [],
};

export const PAYMENT_METHODS = [
  'Cash',
  'Credit Card',
  'Debit Card',
  'UPI',
  'Net Banking',
  'EMI',
  'Cheque',
  'Other',
];

export const POLICY_TYPES: { label: string; value: string }[] = [
  { label: 'Warranty', value: 'warranty' },
  { label: 'Product Protection Plan', value: 'protection' },
  { label: 'Vehicle Insurance', value: 'vehicle' },
  { label: 'Health Insurance', value: 'health' },
  { label: 'Other Insurance', value: 'other' },
];

export const DOCUMENT_CATEGORIES: { label: string; value: string }[] = [
  { label: 'Bill', value: 'bill' },
  { label: 'Invoice', value: 'invoice' },
  { label: 'Warranty Document', value: 'warranty' },
  { label: 'Insurance Policy', value: 'insurance' },
  { label: 'Service Report', value: 'service' },
  { label: 'Claim Document', value: 'claim_doc' },
  { label: 'Supporting Evidence', value: 'evidence' },
  { label: 'Other', value: 'other' },
];

export const CLAIM_STATUSES: { label: string; value: string }[] = [
  { label: 'Issue Reported', value: 'issue_reported' },
  { label: 'Eligibility Check', value: 'eligibility_check' },
  { label: 'Documents Prepared', value: 'documents_prepared' },
  { label: 'Claim Submitted', value: 'claim_submitted' },
  { label: 'Verification', value: 'verification' },
  { label: 'Decision', value: 'decision' },
  { label: 'Resolved', value: 'resolved' },
];

export const CLAIM_TYPES: { label: string; value: string }[] = [
  { label: 'Warranty Claim', value: 'warranty' },
  { label: 'Insurance Claim', value: 'insurance' },
  { label: 'Protection Plan', value: 'protection' },
  { label: 'Other', value: 'other' },
];

export const NOTIFICATION_PRIORITIES: { label: string; value: string }[] = [
  { label: 'Urgent', value: 'urgent' },
  { label: 'Upcoming', value: 'upcoming' },
  { label: 'Informational', value: 'informational' },
  { label: 'Completed', value: 'completed' },
];

export const ALLOWED_MIME_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
  'image/heic',
  'image/heif',
];

export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
