export function formatDate(date: string | null | undefined): string {
  if (!date) return '—';
  return new Date(date).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatCurrency(amount: number | null | undefined): string {
  if (amount == null) return '—';
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function daysUntil(date: string | null | undefined): number {
  if (!date) return Infinity;
  const target = new Date(date);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  target.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export function isExpired(date: string | null | undefined): boolean {
  if (!date) return false;
  return daysUntil(date) < 0;
}

export function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

export function statusBadgeClass(status: string): string {
  const map: Record<string, string> = {
    active: 'badge-success',
    expired: 'badge-error',
    cancelled: 'badge-neutral',
    overdue: 'badge-error',
    completed: 'badge-success',
    paid: 'badge-success',
    pending: 'badge-warning',
    failed: 'badge-error',
    issue_reported: 'badge-info',
    eligibility_check: 'badge-info',
    documents_prepared: 'badge-info',
    claim_submitted: 'badge-warning',
    verification: 'badge-warning',
    decision: 'badge-warning',
    resolved: 'badge-success',
    likely_eligible: 'badge-success',
    needs_verification: 'badge-warning',
    likely_not_eligible: 'badge-error',
    available: 'badge-success',
    missing: 'badge-error',
    needs_verification: 'badge-warning',
    urgent: 'badge-error',
    upcoming: 'badge-warning',
    informational: 'badge-info',
    completed: 'badge-success',
  };
  return map[status] ?? 'badge-neutral';
}

export function statusLabel(status: string): string {
  const map: Record<string, string> = {
    active: 'Active',
    expired: 'Expired',
    cancelled: 'Cancelled',
    overdue: 'Overdue',
    completed: 'Completed',
    paid: 'Paid',
    pending: 'Pending',
    failed: 'Failed',
    issue_reported: 'Issue Reported',
    eligibility_check: 'Eligibility Check',
    documents_prepared: 'Documents Prepared',
    claim_submitted: 'Claim Submitted',
    verification: 'Verification',
    decision: 'Decision',
    resolved: 'Resolved',
    likely_eligible: 'Likely Eligible',
    needs_verification: 'Needs Verification',
    likely_not_eligible: 'Likely Not Eligible',
    available: 'Available',
    missing: 'Missing',
  };
  return map[status] ?? status.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

export function claimReadinessColor(score: number): string {
  if (score >= 75) return 'text-accent-600';
  if (score >= 50) return 'text-warning-600';
  return 'text-error-600';
}

export function claimReadinessBg(score: number): string {
  if (score >= 75) return 'bg-accent-500';
  if (score >= 50) return 'bg-warning-500';
  return 'bg-error-500';
}
