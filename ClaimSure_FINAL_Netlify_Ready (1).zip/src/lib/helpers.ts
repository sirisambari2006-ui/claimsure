import { supabase } from '@/lib/supabase';

export async function logAudit(
  action: string,
  entityType?: string,
  entityId?: string,
  details?: Record<string, unknown>
) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  await supabase.from('audit_logs').insert({
    user_id: user.id,
    action,
    entity_type: entityType,
    entity_id: entityId,
    details: details || {},
  });
}

export async function createNotification(
  userId: string,
  title: string,
  description: string,
  priority: 'urgent' | 'upcoming' | 'informational' | 'completed',
  category: string,
  dueDate?: string,
  relatedId?: string,
  relatedType?: string
) {
  await supabase.from('notifications').insert({
    user_id: userId,
    title,
    description,
    priority,
    category,
    due_date: dueDate || null,
    related_id: relatedId || null,
    related_type: relatedType || null,
  });
}

export async function uploadDocument(
  file: File,
  userId: string
): Promise<{ path: string; error: string | null }> {
  const ext = file.name.split('.').pop();
  const fileName = `${crypto.randomUUID()}.${ext}`;
  const path = `${userId}/${fileName}`;

  const { error } = await supabase.storage
    .from('user_documents')
    .upload(path, file, {
      contentType: file.type,
      upsert: false,
    });

  if (error) return { path: '', error: error.message };

  return { path, error: null };
}

export async function getDocumentUrl(path: string): Promise<string | null> {
  const { data } = await supabase.storage
    .from('user_documents')
    .createSignedUrl(path, 3600);

  return data?.signedUrl || null;
}

export async function deleteDocument(path: string): Promise<string | null> {
  const { error } = await supabase.storage.from('user_documents').remove([path]);
  return error?.message || null;
}
