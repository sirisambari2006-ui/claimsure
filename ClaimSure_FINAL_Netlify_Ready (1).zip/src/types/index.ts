export type ProductCategory =
  | 'Laptop'
  | 'Mobile'
  | 'Camera'
  | 'Television'
  | 'Refrigerator'
  | 'Washing Machine'
  | 'Air Conditioner'
  | 'Car'
  | 'Bike'
  | 'Other';

export type PolicyType =
  | 'warranty'
  | 'protection'
  | 'vehicle'
  | 'health'
  | 'other';

export type ClaimStatus =
  | 'issue_reported'
  | 'eligibility_check'
  | 'documents_prepared'
  | 'claim_submitted'
  | 'verification'
  | 'decision'
  | 'resolved';

export type EligibilityResult =
  | 'likely_eligible'
  | 'needs_verification'
  | 'likely_not_eligible';

export type NotificationPriority =
  | 'urgent'
  | 'upcoming'
  | 'informational'
  | 'completed';

export type DocumentCategory =
  | 'bill'
  | 'invoice'
  | 'warranty'
  | 'insurance'
  | 'service'
  | 'claim_doc'
  | 'evidence'
  | 'other';

export interface Profile {
  id: string;
  full_name: string | null;
  phone: string | null;
  preferred_language: string;
  notification_prefs: Record<string, boolean>;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  user_id: string;
  name: string;
  category: string;
  brand: string | null;
  model: string | null;
  serial_number: string | null;
  purchase_date: string | null;
  purchase_price: number | null;
  seller: string | null;
  payment_method: string | null;
  warranty_period: string | null;
  warranty_expiry: string | null;
  notes: string | null;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProductDocument {
  id: string;
  user_id: string;
  product_id: string | null;
  policy_id: string | null;
  claim_id: string | null;
  name: string;
  category: string;
  storage_path: string | null;
  mime_type: string | null;
  file_size: number | null;
  extracted_data: Record<string, unknown>;
  is_verified: boolean;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface InsurancePolicy {
  id: string;
  user_id: string;
  product_id: string | null;
  provider: string;
  policy_name: string | null;
  policy_type: string;
  policy_number: string | null;
  coverage: string[];
  conditions: string | null;
  exclusions: string[];
  required_documents: string[];
  claim_channel: string | null;
  claim_deadline_days: number | null;
  effective_date: string | null;
  expiry_date: string | null;
  source_document_id: string | null;
  policy_status: string;
  ai_explanation: string | null;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface Claim {
  id: string;
  user_id: string;
  product_id: string | null;
  policy_id: string | null;
  issue: string;
  claim_type: string;
  status: string;
  eligibility_result: string | null;
  eligibility_reasoning: Record<string, unknown>;
  claim_readiness_score: number;
  readiness_breakdown: Record<string, number>;
  reference_number: string | null;
  deadline: string | null;
  notes: string | null;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface ClaimEvidence {
  id: string;
  claim_id: string;
  user_id: string;
  item: string;
  status: 'available' | 'missing' | 'needs_verification';
  document_id: string | null;
  is_required: boolean;
  created_at: string;
}

export interface ClaimEvent {
  id: string;
  claim_id: string;
  user_id: string;
  stage: string;
  description: string | null;
  event_date: string;
  created_at: string;
}

export interface EMIAccount {
  id: string;
  user_id: string;
  product_id: string | null;
  total_amount: number;
  down_payment: number;
  emi_amount: number;
  total_installments: number;
  paid_installments: number;
  start_date: string | null;
  next_due_date: string | null;
  completion_date: string | null;
  status: string;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface EMIPayment {
  id: string;
  emi_account_id: string;
  user_id: string;
  amount: number;
  installment_number: number;
  payment_date: string;
  status: string;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  priority: string;
  category: string;
  related_id: string | null;
  related_type: string | null;
  is_read: boolean;
  due_date: string | null;
  created_at: string;
}

export interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  entity_type: string | null;
  entity_id: string | null;
  details: Record<string, unknown>;
  created_at: string;
}
