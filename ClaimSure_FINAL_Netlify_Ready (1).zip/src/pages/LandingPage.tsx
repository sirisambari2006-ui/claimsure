import { Link } from 'react-router-dom';
import {
  ShieldCheck,
  ArrowRight,
  FileText,
  Brain,
  Lock,
  Bot,
  CheckCircle2,
  Languages,
  Bell,
  CreditCard,
  Package,
  Sparkles,
  TrendingUp,
  Clock,
} from 'lucide-react';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Nav */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-sm border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary-600 to-navy-700 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-lg text-navy-900">ClaimSure</span>
          </div>
          <div className="flex items-center gap-3">
            <LanguageSwitcher />
            <Link to="/login" className="btn-ghost text-sm hidden sm:inline-flex">
              Sign In
            </Link>
            <Link to="/signup" className="btn-primary text-sm">
              Get Started
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-navy-50" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-primary-100/30 rounded-full blur-3xl -z-0" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary-50 border border-primary-100 text-primary-700 text-sm font-medium mb-6 animate-fade-in">
              <Sparkles className="w-4 h-4" />
              AI-Powered Claim Intelligence Platform
            </div>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-navy-900 leading-tight text-balance animate-fade-in-up">
              Your documents. Your protection.
              <span className="block text-primary-600 mt-2">Your claim confidence.</span>
            </h1>
            <p className="mt-6 text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed animate-fade-in-up">
              Manage bills, warranties, insurance policies, EMIs and claims in one secure platform.
              Understand your coverage and know what evidence you may need before starting a claim.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center animate-fade-in-up">
              <Link to="/signup" className="btn-primary text-base px-6 py-3">
                Get Started
                <ArrowRight className="w-5 h-5" />
              </Link>
              <a href="#how-it-works" className="btn-secondary text-base px-6 py-3">
                See How It Works
              </a>
            </div>
          </div>

          {/* Workflow visual */}
          <div className="mt-16 lg:mt-20">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-lg p-6 lg:p-8">
              <div className="flex flex-wrap items-center justify-center gap-2 lg:gap-4">
                {[
                  { label: 'Document', icon: FileText },
                  { label: 'AI Understanding', icon: Brain },
                  { label: 'Policy Match', icon: ShieldCheck },
                  { label: 'Eligibility', icon: CheckCircle2 },
                  { label: 'Evidence', icon: Package },
                  { label: 'Claim', icon: ShieldCheck },
                ].map((step, i, arr) => (
                  <div key={step.label} className="flex items-center gap-2 lg:gap-4">
                    <div className="flex flex-col items-center gap-2">
                      <div className="w-12 h-12 lg:w-14 lg:h-14 rounded-xl bg-gradient-to-br from-primary-50 to-navy-50 border border-primary-100 flex items-center justify-center">
                        <step.icon className="w-6 h-6 text-primary-600" />
                      </div>
                      <span className="text-xs lg:text-sm font-medium text-navy-700">{step.label}</span>
                    </div>
                    {i < arr.length - 1 && (
                      <ArrowRight className="w-4 h-4 text-slate-300 hidden sm:block" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-display text-3xl lg:text-4xl font-bold text-navy-900">The Problem</h2>
            <p className="mt-4 text-slate-600 text-lg">
              Managing product protection is harder than it should be.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: 'Lost Bills', desc: 'Paper bills fade, get misplaced, or are thrown away with packaging.' },
              { title: 'Forgotten Expiry', desc: 'Warranty and insurance renewal dates slip by unnoticed.' },
              { title: 'Unclear Coverage', desc: 'Policy conditions are dense and hard to understand.' },
              { title: 'Claim Confusion', desc: 'Users do not know what evidence they need or whether they are eligible.' },
            ].map((item) => (
              <div key={item.title} className="card p-6">
                <h3 className="font-semibold text-navy-800 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Solution */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-display text-3xl lg:text-4xl font-bold text-navy-900">The Solution</h2>
            <p className="mt-4 text-slate-600 text-lg">
              ClaimSure converts scattered documents into explainable claim intelligence.
            </p>
          </div>
          <div className="grid lg:grid-cols-3 gap-6">
            {[
              { icon: FileText, title: 'Document Hub', desc: 'Upload and organize all your bills, warranties, policies, and service records in one secure digital locker.' },
              { icon: Brain, title: 'AI Understanding', desc: 'Extract key information from your documents — product details, dates, amounts, and coverage.' },
              { icon: ShieldCheck, title: 'Claim Intelligence', desc: 'Assess claim eligibility, get evidence checklists, and track your claim journey from start to finish.' },
            ].map((item) => (
              <div key={item.title} className="card-hover p-8">
                <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center mb-4">
                  <item.icon className="w-6 h-6 text-primary-600" />
                </div>
                <h3 className="font-display text-xl font-semibold text-navy-900 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="py-20 bg-navy-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-display text-3xl lg:text-4xl font-bold">How ClaimSure Works</h2>
            <p className="mt-4 text-navy-200 text-lg">From document to claim — a guided journey.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'Add Your Products', desc: 'Register products manually or upload bills for AI-assisted extraction.' },
              { step: '02', title: 'Upload Documents', desc: 'Store bills, warranties, and policies in your secure digital locker.' },
              { step: '03', title: 'Assess Eligibility', desc: 'Report an issue and let the Claim Intelligence Engine evaluate coverage.' },
              { step: '04', title: 'Track Your Claim', desc: 'Follow your claim journey with evidence checklists and status updates.' },
            ].map((item) => (
              <div key={item.step} className="bg-navy-800/50 rounded-xl border border-navy-700 p-6">
                <span className="text-3xl font-display font-bold text-primary-400">{item.step}</span>
                <h3 className="mt-3 font-semibold text-white text-lg">{item.title}</h3>
                <p className="mt-2 text-sm text-navy-300">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Claim Intelligence Engine */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent-50 text-accent-700 text-sm font-medium mb-4">
                <Sparkles className="w-4 h-4" />
                Core USP
              </div>
              <h2 className="font-display text-3xl lg:text-4xl font-bold text-navy-900 mb-4">
                Claim Intelligence Engine
              </h2>
              <p className="text-slate-600 text-lg mb-6">
                Our deterministic engine analyzes your product data, warranty status, insurance coverage,
                and available documents to produce an explainable eligibility assessment.
              </p>
              <ul className="space-y-3">
                {[
                  'Analyzes warranty and policy coverage against your reported issue',
                  'Produces an explainable Claim Readiness Score from actual data',
                  'Generates a tailored evidence checklist',
                  'Never guarantees approval — always transparent about uncertainty',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent-600 mt-0.5 shrink-0" />
                    <span className="text-sm text-navy-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="card p-6 lg:p-8 bg-gradient-to-br from-slate-50 to-primary-50/30">
              <div className="space-y-4">
                <div className="bg-white rounded-lg border border-slate-200 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-navy-700">Claim Assessment</span>
                    <span className="badge-warning">Needs Verification</span>
                  </div>
                  <p className="text-xs text-slate-500 mb-3">Product: Dell Laptop — Screen not working</p>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-accent-500" />
                      <span className="text-slate-600">Within warranty period</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-accent-500" />
                      <span className="text-slate-600">Purchase invoice available</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-accent-500" />
                      <span className="text-slate-600">Warranty document available</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-warning-500" />
                      <span className="text-slate-600">Service report missing</span>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-slate-100">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-medium text-navy-700">Claim Readiness</span>
                      <span className="text-sm font-bold text-warning-600">76%</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-warning-500 h-2 rounded-full" style={{ width: '76%' }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Features */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-display text-3xl lg:text-4xl font-bold text-navy-900">Key Features</h2>
            <p className="mt-4 text-slate-600 text-lg">Everything you need to manage your protection.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Package, title: 'Product Management', desc: 'Track all your products with full details — brand, model, serial number, purchase info.' },
              { icon: FileText, title: 'Document Locker', desc: 'Securely store and organize bills, warranties, policies, and service reports.' },
              { icon: CreditCard, title: 'EMI Manager', desc: 'Track EMI payments, due dates, and completion progress.' },
              { icon: ShieldCheck, title: 'Policy Intelligence', desc: 'Store and understand your insurance policies with AI-generated explanations.' },
              { icon: Brain, title: 'AI Bill Reader', desc: 'Upload bills and let AI extract key information for your verification.' },
              { icon: Bell, title: 'Smart Reminders', desc: 'Get notified about warranty expiry, EMI due dates, and policy renewals.' },
            ].map((item) => (
              <div key={item.title} className="card-hover p-6">
                <div className="w-10 h-10 rounded-lg bg-primary-50 flex items-center justify-center mb-4">
                  <item.icon className="w-5 h-5 text-primary-600" />
                </div>
                <h3 className="font-semibold text-navy-900 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="card p-8">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-accent-50 flex items-center justify-center shrink-0">
                      <Lock className="w-5 h-5 text-accent-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-navy-900">Private by Design</h3>
                      <p className="text-sm text-slate-500 mt-1">Row Level Security ensures each user can only access their own data.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary-50 flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-5 h-5 text-primary-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-navy-900">Secure Storage</h3>
                      <p className="text-sm text-slate-500 mt-1">Documents are stored in private, user-scoped storage with access controls.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-warning-50 flex items-center justify-center shrink-0">
                      <TrendingUp className="w-5 h-5 text-warning-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-navy-900">Audit Trail</h3>
                      <p className="text-sm text-slate-500 mt-1">Security-sensitive actions are logged for your review in the Security Center.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="font-display text-3xl lg:text-4xl font-bold text-navy-900 mb-4">Security & Privacy</h2>
              <p className="text-slate-600 text-lg">
                Your data is protected with industry-standard access controls. Every user's records are
                isolated through database-level Row Level Security policies — not just application logic.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Multilingual */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-50 text-primary-700 text-sm font-medium mb-4">
            <Languages className="w-4 h-4" />
            Multilingual Support
          </div>
          <h2 className="font-display text-3xl lg:text-4xl font-bold text-navy-900 mb-4">
            Available in 7 Languages
          </h2>
          <p className="text-slate-600 text-lg max-w-2xl mx-auto mb-10">
            ClaimSure speaks your language. Switch between English, Telugu, Hindi, Tamil, Kannada, Malayalam, and Marathi.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {['English', 'తెలుగు', 'हिन्दी', 'தமிழ்', 'ಕನ್ನಡ', 'മലയാളം', 'मराठी'].map((lang) => (
              <span key={lang} className="px-4 py-2 rounded-lg bg-white border border-slate-200 text-navy-700 font-medium shadow-sm">
                {lang}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* AI Assistant */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-50 text-primary-700 text-sm font-medium mb-4">
                <Bot className="w-4 h-4" />
                AI Claim Assistant
              </div>
              <h2 className="font-display text-3xl lg:text-4xl font-bold text-navy-900 mb-4">
                Your Personal Claim Guide
              </h2>
              <p className="text-slate-600 text-lg mb-6">
                The AI Claim Assistant guides you through the claim process — from identifying the right
                product and policy to checking coverage, understanding exclusions, and preparing evidence.
              </p>
              <ul className="space-y-3">
                {[
                  'Uses your actual product and policy data to provide guidance',
                  'Identifies missing evidence and suggests next steps',
                  'Calculates claim readiness based on available documents',
                  'Available with voice input where browser capabilities allow',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent-600 mt-0.5 shrink-0" />
                    <span className="text-sm text-navy-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="card p-6 bg-gradient-to-br from-slate-50 to-primary-50/30">
              <div className="space-y-3">
                <div className="flex justify-end">
                  <div className="bg-primary-600 text-white rounded-2xl rounded-tr-sm px-4 py-2.5 max-w-xs text-sm">
                    My phone screen stopped working.
                  </div>
                </div>
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-4 py-2.5 max-w-xs text-sm text-navy-700">
                    I found your Samsung Galaxy S23. It is within the 1-year warranty. However, I notice
                    you do not have a service report on file. Would you like me to check your claim readiness?
                  </div>
                </div>
                <div className="flex justify-end">
                  <div className="bg-primary-600 text-white rounded-2xl rounded-tr-sm px-4 py-2.5 max-w-xs text-sm">
                    Yes, please.
                  </div>
                </div>
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-4 py-2.5 max-w-xs text-sm text-navy-700">
                    Your claim readiness is 72%. You have the purchase invoice and warranty document.
                    Missing: service report and product photographs. Upload these to improve your score.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-br from-primary-600 to-navy-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-display text-3xl lg:text-5xl font-bold text-white mb-4">
            Start managing your protection today
          </h2>
          <p className="text-primary-100 text-lg mb-8 max-w-2xl mx-auto">
            Join ClaimSure and transform how you manage bills, warranties, insurance, and claims.
          </p>
          <Link
            to="/signup"
            className="inline-flex items-center gap-2 bg-white text-primary-700 font-semibold px-6 py-3 rounded-lg hover:bg-primary-50 transition-colors"
          >
            Get Started Free
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-navy-950 text-navy-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-600 to-navy-700 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold text-white">ClaimSure</span>
          </div>
          <p className="text-sm text-navy-400">
            Your documents. Your protection. Your claim confidence.
          </p>
        </div>
      </footer>
    </div>
  );
}
