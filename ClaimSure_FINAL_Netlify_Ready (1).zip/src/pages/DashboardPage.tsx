import { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Package,
  ShieldCheck,
  FileText,
  CreditCard,
  AlertTriangle,
  Clock,
  TrendingUp,
  ArrowRight,
  Sparkles,
  Bell,
  CheckCircle2,
  Upload,
  Plus,
  FilePlus,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useUserData } from '@/hooks/useUserData';
import { useI18n } from '@/context/I18nContext';
import {
  formatDate,
  formatCurrency,
  daysUntil,
  isExpired,
  getGreeting,
  statusBadgeClass,
  statusLabel,
  claimReadinessColor,
  claimReadinessBg,
} from '@/lib/utils';
import { calculateClaimReadiness } from '@/lib/claimIntelligence';
import { LoadingSpinner, CardLoader, EmptyState } from '@/components/ui/States';

export default function DashboardPage() {
  const { profile, user } = useAuth();
  const { t } = useI18n();
  const navigate = useNavigate();
  const { products, documents, policies, claims, emis, auditLogs, loading } = useUserData();

  const stats = useMemo(() => {
    const today = new Date();
    const activeProducts = products.length;
    const activeWarranties = products.filter(
      (p) => p.warranty_expiry && !isExpired(p.warranty_expiry)
    ).length;
    const insurancePolicies = policies.filter((p) => p.policy_status === 'active').length;

    const upcomingEmi = emis
      .filter((e) => e.status === 'active' && e.next_due_date)
      .sort((a, b) => new Date(a.next_due_date!).getTime() - new Date(b.next_due_date!).getTime())
      .slice(0, 1);

    const pendingClaims = claims.filter(
      (c) => c.status !== 'resolved' && c.status !== 'decision'
    ).length;

    const expiringItems = [
      ...products
        .filter((p) => p.warranty_expiry)
        .map((p) => ({
          name: p.name,
          expiry: p.warranty_expiry!,
          type: 'Warranty',
          daysLeft: daysUntil(p.warranty_expiry),
        })),
      ...policies
        .filter((p) => p.expiry_date)
        .map((p) => ({
          name: p.policy_name || p.provider,
          expiry: p.expiry_date!,
          type: 'Insurance',
          daysLeft: daysUntil(p.expiry_date),
        })),
    ]
      .filter((item) => item.daysLeft >= 0 && item.daysLeft <= 60)
      .sort((a, b) => a.daysLeft - b.daysLeft)
      .slice(0, 5);

    return {
      activeProducts,
      activeWarranties,
      insurancePolicies,
      upcomingEmi: upcomingEmi[0] || null,
      pendingClaims,
      expiringItems,
    };
  }, [products, policies, claims, emis]);

  const overallReadiness = useMemo(() => {
    if (products.length === 0) return { total: 0, missingItems: [] as string[] };
    const firstProduct = products[0];
    const productDocs = documents.filter((d) => d.product_id === firstProduct.id);
    const productPolicies = policies.filter((p) => p.product_id === firstProduct.id);
    return calculateClaimReadiness(firstProduct, productDocs, productPolicies, '', []);
  }, [products, documents, policies]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-24 bg-slate-100 rounded-xl animate-pulse" />
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <CardLoader key={i} />
          ))}
        </div>
      </div>
    );
  }

  const greeting = getGreeting();
  const userName = profile?.full_name || user?.email?.split('@')[0] || 'User';
  const unreadNotifs = 0;

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Greeting */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-navy-900">
            {greeting}, {userName}
          </h1>
          <p className="text-sm text-slate-500 mt-1">{t('dashboard.subtitle')}</p>
        </div>
        <button
          onClick={() => navigate('/claims')}
          className="btn-primary"
        >
          <Sparkles className="w-4 h-4" />
          {t('dashboard.whatCanIClaim')}
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard
          icon={Package}
          label={t('dashboard.activeProducts')}
          value={stats.activeProducts}
          color="primary"
          link="/products"
        />
        <StatCard
          icon={ShieldCheck}
          label={t('dashboard.activeWarranties')}
          value={stats.activeWarranties}
          color="accent"
          link="/products"
        />
        <StatCard
          icon={FileText}
          label={t('dashboard.insurancePolicies')}
          value={stats.insurancePolicies}
          color="navy"
          link="/policies"
        />
        <StatCard
          icon={CreditCard}
          label={t('dashboard.upcomingEMI')}
          value={stats.upcomingEmi ? formatCurrency(stats.upcomingEmi.emi_amount) : '—'}
          color="warning"
          link="/emis"
        />
        <StatCard
          icon={AlertTriangle}
          label={t('dashboard.pendingClaims')}
          value={stats.pendingClaims}
          color="error"
          link="/claims"
        />
        <StatCard
          icon={Clock}
          label={t('dashboard.expiringSoon')}
          value={stats.expiringItems.length}
          color="warning"
          link="/notifications"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* EMI Progress */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-navy-900">{t('dashboard.emiProgress')}</h2>
            <Link to="/emis" className="text-xs text-primary-600 hover:text-primary-700 font-medium">
              View all
            </Link>
          </div>
          {emis.length === 0 ? (
            <p className="text-sm text-slate-400 py-6 text-center">No EMI accounts yet.</p>
          ) : (
            <div className="space-y-4">
              {emis.slice(0, 3).map((emi) => {
                const paidAmount = emi.down_payment + emi.emi_amount * emi.paid_installments;
                const pct = emi.total_amount > 0 ? (paidAmount / emi.total_amount) * 100 : 0;
                return (
                  <div key={emi.id}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-navy-700 truncate">
                        {products.find((p) => p.id === emi.product_id)?.name || 'EMI'}
                      </span>
                      <span className="text-xs text-slate-500">
                        {formatCurrency(paidAmount)} / {formatCurrency(emi.total_amount)}
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div
                        className="bg-primary-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(100, pct)}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs text-slate-400">
                        {emi.paid_installments}/{emi.total_installments} installments
                      </span>
                      <span className="text-xs font-medium text-navy-600">{Math.round(pct)}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Claim Readiness */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-navy-900">{t('dashboard.claimReadiness')}</h2>
            <Link to="/claims" className="text-xs text-primary-600 hover:text-primary-700 font-medium">
              View claims
            </Link>
          </div>
          {products.length === 0 ? (
            <p className="text-sm text-slate-400 py-6 text-center">
              Add a product to calculate readiness.
            </p>
          ) : (
            <div className="flex flex-col items-center py-2">
              <div className="relative w-32 h-32">
                <svg className="w-32 h-32 -rotate-90" viewBox="0 0 120 120">
                  <circle cx="60" cy="60" r="52" fill="none" stroke="#e2e8f0" strokeWidth="10" />
                  <circle
                    cx="60"
                    cy="60"
                    r="52"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="10"
                    strokeLinecap="round"
                    strokeDasharray={`${(overallReadiness.total / 100) * 327} 327`}
                    className={claimReadinessColor(overallReadiness.total)}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className={`text-3xl font-bold ${claimReadinessColor(overallReadiness.total)}`}>
                    {overallReadiness.total}%
                  </span>
                  <span className="text-xs text-slate-400">Ready</span>
                </div>
              </div>
              {overallReadiness.missingItems.length > 0 && (
                <p className="text-sm text-slate-500 text-center mt-4">
                  {overallReadiness.missingItems.length} document(s) required to improve claim readiness.
                </p>
              )}
            </div>
          )}
        </div>

        {/* Warranty/Insurance Expiry */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-navy-900">{t('dashboard.warrantyExpiry')}</h2>
          </div>
          {stats.expiringItems.length === 0 ? (
            <p className="text-sm text-slate-400 py-6 text-center">
              Nothing expiring in the next 60 days.
            </p>
          ) : (
            <div className="space-y-3">
              {stats.expiringItems.map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-navy-700 truncate">{item.name}</p>
                    <p className="text-xs text-slate-400">{item.type} — {formatDate(item.expiry)}</p>
                  </div>
                  <span
                    className={
                      item.daysLeft <= 7
                        ? 'badge-error'
                        : item.daysLeft <= 30
                          ? 'badge-warning'
                          : 'badge-info'
                    }
                  >
                    {item.daysLeft}d left
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-navy-900">{t('dashboard.recentActivity')}</h2>
        </div>
        {auditLogs.length === 0 ? (
          <EmptyState
            icon={<Bell className="w-7 h-7" />}
            title="No recent activity"
            description="Your recent actions will appear here as you use ClaimSure."
          />
        ) : (
          <div className="space-y-2">
            {auditLogs.slice(0, 8).map((log) => (
              <div key={log.id} className="flex items-center gap-3 py-2 border-b border-slate-50 last:border-0">
                <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                  <ActivityIcon action={log.action} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-navy-700">{formatActionText(log.action, log.entity_type)}</p>
                  <p className="text-xs text-slate-400">{formatDate(log.created_at)}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <QuickAction icon={Plus} label="Add Product" link="/products" />
        <QuickAction icon={Upload} label="Upload Document" link="/locker" />
        <QuickAction icon={FilePlus} label="Start a Claim" link="/claims" />
        <QuickAction icon={Sparkles} label="Ask AI Assistant" link="/assistant" />
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  color,
  link,
}: {
  icon: typeof Package;
  label: string;
  value: string | number;
  color: 'primary' | 'accent' | 'navy' | 'warning' | 'error';
  link: string;
}) {
  const colors = {
    primary: 'bg-primary-50 text-primary-600',
    accent: 'bg-accent-50 text-accent-600',
    navy: 'bg-navy-50 text-navy-600',
    warning: 'bg-warning-50 text-warning-600',
    error: 'bg-error-50 text-error-600',
  };
  return (
    <Link to={link} className="card-hover p-5 group">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 rounded-lg ${colors[color]} flex items-center justify-center`}>
          <Icon className="w-5 h-5" />
        </div>
        <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500 transition-colors" />
      </div>
      <p className="text-2xl font-bold text-navy-900">{value}</p>
      <p className="text-sm text-slate-500 mt-0.5">{label}</p>
    </Link>
  );
}

function QuickAction({ icon: Icon, label, link }: { icon: typeof Plus; label: string; link: string }) {
  return (
    <Link to={link} className="card-hover p-4 flex items-center gap-3 group">
      <div className="w-10 h-10 rounded-lg bg-primary-50 text-primary-600 flex items-center justify-center group-hover:bg-primary-100 transition-colors">
        <Icon className="w-5 h-5" />
      </div>
      <span className="text-sm font-medium text-navy-700">{label}</span>
    </Link>
  );
}

function ActivityIcon({ action }: { action: string }) {
  const iconClass = "w-4 h-4 text-slate-500";
  if (action.includes('login') || action.includes('logout')) return <CheckCircle2 className={iconClass} />;
  if (action.includes('upload')) return <Upload className={iconClass} />;
  if (action.includes('create')) return <Plus className={iconClass} />;
  if (action.includes('delete')) return <AlertTriangle className={iconClass} />;
  return <Bell className={iconClass} />;
}

function formatActionText(action: string, entityType: string | null): string {
  const verb = action.replace(/_/g, ' ');
  const entity = entityType ? ` ${entityType}` : '';
  return `${verb}${entity}`.replace(/\b\w/g, (c) => c.toUpperCase());
}
