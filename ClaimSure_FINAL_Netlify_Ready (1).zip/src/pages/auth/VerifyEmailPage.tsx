import { Link } from 'react-router-dom';
import { MailCheck, ArrowRight } from 'lucide-react';
import { AuthLayout } from './AuthLayout';

export default function VerifyEmailPage() {
  return (
    <AuthLayout>
      <div className="text-center">
        <div className="w-16 h-16 rounded-full bg-accent-50 flex items-center justify-center mx-auto mb-6">
          <MailCheck className="w-8 h-8 text-accent-600" />
        </div>
        <h1 className="font-display text-2xl font-bold text-navy-900 mb-2">Check your email</h1>
        <p className="text-sm text-slate-500 mb-8 max-w-sm mx-auto">
          We've sent you a verification link. Click the link in the email to verify your account,
          then sign in to continue.
        </p>
        <Link to="/login" className="btn-primary w-full">
          Continue to Sign In
          <ArrowRight className="w-4 h-4" />
        </Link>
        <p className="mt-6 text-sm text-slate-500">
          Didn't receive an email?{' '}
          <Link to="/signup" className="text-primary-600 hover:text-primary-700 font-medium">
            Try again
          </Link>
        </p>
      </div>
    </AuthLayout>
  );
}
