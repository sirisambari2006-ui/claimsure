import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowRight, ArrowLeft } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/context/ToastContext';
import { AuthLayout } from './AuthLayout';
import { LoadingSpinner } from '@/components/ui/States';

export default function ForgotPasswordPage() {
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    setLoading(false);

    if (error) {
      toast(error.message, 'error');
      return;
    }

    setSent(true);
    toast('Password reset link sent to your email', 'success');
  };

  return (
    <AuthLayout>
      <div className="mb-8">
        <Link to="/login" className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-navy-900 mb-6">
          <ArrowLeft className="w-4 h-4" />
          Back to sign in
        </Link>
        <h1 className="font-display text-2xl font-bold text-navy-900 mb-2">Reset your password</h1>
        <p className="text-sm text-slate-500">
          Enter your email and we'll send you a password reset link.
        </p>
      </div>

      {sent ? (
        <div className="bg-accent-50 border border-accent-200 rounded-lg p-4 text-sm text-accent-800">
          A password reset link has been sent to <strong>{email}</strong>. Check your inbox and follow
          the instructions to reset your password.
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="label">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input pl-10"
                placeholder="you@example.com"
              />
            </div>
          </div>

          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading ? <LoadingSpinner size={18} /> : (
              <>
                Send Reset Link
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      )}
    </AuthLayout>
  );
}
