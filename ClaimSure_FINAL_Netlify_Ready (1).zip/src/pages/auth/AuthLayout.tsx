import { type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';

export function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-navy-900 via-navy-800 to-primary-900 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-navy-500/20 rounded-full blur-3xl" />
        <div className="relative flex flex-col justify-between p-12 text-white w-full">
          <Link to="/" className="flex items-center gap-2.5 w-fit">
            <div className="w-10 h-10 rounded-lg bg-white/10 backdrop-blur flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-xl">ClaimSure</span>
          </Link>
          <div>
            <h1 className="font-display text-4xl font-bold leading-tight mb-4">
              Your documents.<br />
              Your protection.<br />
              Your claim confidence.
            </h1>
            <p className="text-navy-200 text-lg max-w-md">
              AI-powered claim intelligence platform for managing bills, warranties,
              insurance policies, and claims.
            </p>
          </div>
          <p className="text-navy-400 text-sm">
            Smart India Hackathon — ClaimSure Prototype
          </p>
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex flex-col">
        <header className="flex items-center justify-between px-6 py-4">
          <Link to="/" className="flex items-center gap-2 lg:hidden">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-600 to-navy-700 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold text-navy-900">ClaimSure</span>
          </Link>
          <div className="ml-auto"><LanguageSwitcher /></div>
        </header>
        <div className="flex-1 flex items-center justify-center px-6 py-12">
          <div className="w-full max-w-md">{children}</div>
        </div>
      </div>
    </div>
  );
}
